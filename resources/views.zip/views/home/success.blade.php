@extends('layouts.main')
@section('title','Success')
@section('content')
  <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">Success page</h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here:</li>
                            <li><a href="index-2.html">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">Success</li>
                        </ul>
                    </div>
                </header> 
                <div class="page-content">
                    <div class="row page-row" style="min-height: 520px;">  

                     <div class=" col-sm-10 col-sm-offset-1 alert alert-warning" role="alert" >
      Success.
    </div>


                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page--> 
        </div><!--//content-->
@endsection