@extends('layouts.error')
@section('title','404')
@section('content')
        <div class="container">
            <div class="content">
          
                <div  class="title col-sm-12 text-center success" style="font-size:200px;">404</div>


                </div>
            </div>
        </div>
 @endsection
