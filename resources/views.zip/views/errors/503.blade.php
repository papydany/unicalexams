@extends('layouts.error')
@section('title','503')
@section('content')
        <div class="container">
            <div class="content">
          
                <div  class="title col-sm-12 text-center success" style="font-size:120px;">Error 503</div>


                </div>
            </div>
        </div>
 @endsection