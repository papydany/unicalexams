@extends('layouts.error')
@section('title','Error')
@section('content')
        <div class="container">
            <div class="content">
          
                <div  class="title col-sm-12 text-center success" style="font-size:120px;">Opp Error</div>


                </div>
            </div>
        </div>
 @endsection