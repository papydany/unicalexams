

        <!-- ******HEADER****** --> 
        <header class="header">  
          
            <div class="header-main container">
                <h1 class="logo col-md-2 col-sm-2">
                    <a href="url('/result')"><img id="logo" src="assets/images/logo.png" alt="Logo"></a>
                </h1><!--//logo--> 
                <div class="info col-md-8 col-sm-10 text-center text-info">
                <h3>UNIVERSITY OF CALABAR RESULT PORTAL</h3>
                </div>          
             
            </div><!--//header-main-->
        </header><!--//header-->
        
        <!-- ******NAV****** -->
        <nav class="main-nav" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button><!--//nav-toggle-->
                </div><!--//navbar-header-->            
                <div class="navbar-collapse collapse" id="navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active nav-item"><a href="{{url('/oldresult')}}">Home</a></li>
                        <li class="active nav-item"><a href="{{url('/std_logout')}}">Logout</a></li>  
                     
                        
                    </ul><!--//nav-->
                </div><!--//navabr-collapse-->
            </div><!--//container-->
        </nav><!--//main-nav-->