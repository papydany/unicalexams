  <title>@yield('title')</title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">    
    <link rel="shortcut icon" href="favicon.ico">  
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>   
    <!-- Global CSS -->
    <link rel="stylesheet" href="{{URL::to('assets/plugins/bootstrap/css/bootstrap.min.css')}}">   
    <!-- Plugins CSS -->    
    <link rel="stylesheet" href="{{URL::to('assets/plugins/font-awesome/css/font-awesome.css')}}">
    <link rel="stylesheet" href="{{URL::to('assets/plugins/flexslider/flexslider.css')}}">
    <link rel="stylesheet" href="{{URL::to('assets/plugins/pretty-photo/css/prettyPhoto.css')}}"> 
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="{{URL::to('assets/css/styles.css')}}">
   <link href="{{URL::to('parsley.css')}}" rel="stylesheet">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]https://www.sslforfree.com/create?generate&domains=unicalexams.edu.ng-->
    