 
        <div class="bottom-bar">
            <div class="container">
                <div class="row">
                    <small class="copyright  col-xs-12 text-center">Copyright @ {{date('Y')}} Powered By Unical Result Database Unit </small>
                 
                </div><!--//row-->
            </div><!--//container-->
        </div><!--//bottom-bar-->
       

