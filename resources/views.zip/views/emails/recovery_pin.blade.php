<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale = 1.0">
	<title>Recovery Of Pin</title>
</head>
<body style="margin: 0; padding: 0;">
    <table width= "100%" align="center" cellspacing="0" cellpadding="0" style="border: 1px groove cornflowerblue; max-width: 600px;">
    
    	  <tr>
            <td style="padding: 0 5% 0 5%">
             <p  style="font-family: 'Arial Rounded MT Bold',serif; font-size: large; font-weight: 600">Good Day</p>
              <p>Please do find details of your pin.</p>
             <p><b>Matric Number :</b> {{$matric_number}}</p>
                <p><b>Pin : </b>{{$pin}}</p>
                <p><b>Serial Number :</b> {{$id}}</p>
                <p>Regard.<br/>Unical Result Database Unit </p>
                
            </td>
        </tr>
         </table>
</body>
</html>