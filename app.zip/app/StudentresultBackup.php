<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentresultBackup extends Model
{
    //
}
