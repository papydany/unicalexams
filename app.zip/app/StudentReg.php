<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentReg extends Model
{
    //
    protected $connection = 'mysql2';
}
