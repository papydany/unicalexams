<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentsProfile extends Model
{
    //
}
